<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Karatovic\Ontologija;
use Karatovic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/vkaratovic_19/vkaratovic.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija P3 zadatka:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Karatovic\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /napuni', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/vkaratovic_19/vkaratovic.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name'); 
    if($name != ''){

      $i = 0;
      $annotations = "";

     
      $description = $foaf->get($resource, 'dc:description'); // kako izvući dc:description resursa

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; // kako izvući sve anotacije resursa i spojiti u jedan string; "\n" služi da bi u androidu radio newline za svaku anotaciju
      }

      $ontologija = new Ontologija();
      $ontologija->setPodaci(Flight::request()->data);

      $ontologija->setPjesma($name); //tu stavljate svoje varijable.
      $ontologija->setAutor($description);
      $ontologija->setAnotacija($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologija);
      $em->flush();

      /*
      //Prije nego što sam poslao podatke u bazu, prvo bi isprobao neku metodu iz dokumentacije i vidio što bi mi ispisalo.
      Preporučam da tek kada nađete to što trebate onda šaljite u bazu. Dotad zakomentirajte ovaj persist i flush gore, a dolje
      umjesto mojih name type i annotations, provjerite vaše podatke iz ontologije (naravno trebat će prilagoditi i gornje
      metode pošto imamo drukčije ontologije). //

      echo $name .'<br/>';
      echo $types[1] .'<br/>';
      echo $annotations;
      echo '<br/>';
      */
    }
  }

  echo "U bazu je uspješno unijeta ontologija.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Karatovic\Ontologija');
  //$zapisi = $repozitorij->findBy(array('naziv' => $name)); 
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.pjesma LIKE :pjesma')
                        ->setParameter('pjesma', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Karatovic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();

// Ontologije su nam svima slične, ali će trebati neku drugu kombinaciju metoda uvjeta i stringova, evo potencijalne linije koje će vam pomoći
/* Sva svojstva (tj. anotacije prema Protegeu)
foreach ($resource->properties() as $key) {
    echo $i++ . ' ' . $key . ' <br/>';
}
*/

/* Kako maknuti sve iz linka ispred # hashtaga
$url = parse_url($type);
$type2 = $url["fragment"];
*/

/* Svi tipovi
foreach ($resource->types() as $key) {
    echo $i++ . ' ' . $key . ' <br/>';
}
*/

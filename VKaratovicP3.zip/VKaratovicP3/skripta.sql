create database vkaratovic_19 default character set utf8;
use vkaratovic_19;
create table ontologija(
    sifra int not null primary key auto_increment,
    pjesma varchar(255) not null,
    autor varchar(100) not null,
    anotacija text not null
);
insert into ontologija(pjesma, autor, anotacija) values ("ontologija", "test", "test:onrologija");

<?php

namespace Karatovic;

/**
 * @Entity @Table(name="ontologija")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $pjesma;

    /**
    * @Column(type="string")
    */
    private $autor;

    /**
    * @Column(type="string")
    */
    private $anotacija;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getPjesma(){
      return $this->pjesma;
    }
  
    public function setPjesma($pjesma){
      $this->pjesma = $pjesma;
    }
  
    public function getAutor(){
      return $this->autor;
    }
  
    public function setAutor($autor){
      $this->autor = $autor;
    }
  
    public function getAnotacija(){
      return $this->anotacija;
    }
  
    public function setAnotacija($anotacija){
      $this->anotacija = $anotacija;
    }
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
